﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _05_Builder
{
    public class WithCSharp3
    {
        public static void Run()
        {
        }
    }
}
