﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _09_Proxy
{
    public class WithCSharp3
    {
        public static void Run()
        {
            StudentsLottery studentsLotteryForm = new StudentsLottery();
            studentsLotteryForm.ShowDialog();
        }
    }
}
