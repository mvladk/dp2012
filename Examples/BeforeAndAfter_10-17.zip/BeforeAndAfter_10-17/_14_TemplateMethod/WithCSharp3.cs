﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Security.Cryptography;
using System.Net.Sockets;

namespace _14_TemplateMethod
{
    public class WithCSharp3
    {
        public static void Run()
        {
        }
    }
}
