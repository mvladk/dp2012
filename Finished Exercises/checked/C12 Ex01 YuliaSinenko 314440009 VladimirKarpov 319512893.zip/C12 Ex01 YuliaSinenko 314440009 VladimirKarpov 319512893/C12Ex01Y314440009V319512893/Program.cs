﻿// <copyright file="Program.cs" company="Holon Institute of Technology">
//     Copyright (c) Holon Institute of Technology. All rights reserved.
// </copyright>
// <author>319512893 - Vldimir Karpov</author>
// <author>314440009 - Yulia Sinenko</author>

// $G$ RUL-006 (-120) Late submission (-3 days).
// $G$ CSS-999 (-20) You should use some .NET3 features.
// $G$ RUL-003 (-10) Diagram document should be attached to the solution.
// $G$ THE-001 (-17) your grade on diagrams document - 83. please see comments inside the document. (40% of your grade).

namespace C12Ex01Y314440009V319512893
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Windows.Forms;

    public static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        public static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainWindow());
        }
    }
}
