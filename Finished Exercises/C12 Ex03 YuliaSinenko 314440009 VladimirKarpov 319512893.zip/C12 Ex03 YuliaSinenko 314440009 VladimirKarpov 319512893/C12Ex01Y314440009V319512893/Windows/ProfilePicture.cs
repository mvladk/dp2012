﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace C12Ex01Y314440009V319512893
{
    class ProfilePicture
    {
        private PictureBox m_UserProfilePictureBox;

        public PictureBox PictureBox
        {
            get { return m_UserProfilePictureBox; }
            set { m_UserProfilePictureBox = value; }
        }

    }
}
